import requests
from utils import generate_str

sess = requests.Session()
username, password = generate_str(12), generate_str(12)
sess.post("https://example.com/register", json={
    "username": username,
    "password": password,
})
r = sess.get("https://example.com/flags")
print("text with flags:", r.text)
