from string import ascii_letters, digits


alphabet = ascii_letters + digits


def generate_str(length: int) -> str:
    return "".join([alphabet[i % len(alphabet)] for i in range(length)])
